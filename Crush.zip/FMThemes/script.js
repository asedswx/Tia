

document.addEventListener("DOMContentLoaded", function() {
    var nama = localStorage.getItem("nama");
    var namaElement = document.getElementById("nama-ditampilkan");
    if (nama) {
        namaElement.innerHTML = "<p>Hallo, " + nama + "!</p>";
    }
    var pesanElement = document.getElementById("pesan");
    if (pesanElement) {
        pesanElement.classList.remove("hidden");
    }
});
document.addEventListener("DOMContentLoaded", function () {
    const video = document.getElementById("myVideo");

    video.addEventListener("ended", function () {
        // Saat video selesai, ulangi pemutaran
        video.currentTime = 0;
        video.play();
    });
});
